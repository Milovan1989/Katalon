<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>QASandBox</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>df33c04e-bfa3-4048-8fb7-f12c3fe261cd</testSuiteGuid>
   <testCaseLink>
      <guid>6d7f45c8-0f05-4a02-824f-795fae3aa8c0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Report UI Overview</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2f6a4fd1-5075-49d0-b9c2-a082cf9e2782</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard UI Overview</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9e441b35-8e31-4049-afee-9bbaf5037df2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Profile UI Overview</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>972497d4-3a0d-4100-bcf1-ef43abfd23b2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Testcases UI Overview</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>09349a77-fcb0-4f67-9b8e-2a73b7fcde96</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Playground UI Overview</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>23b4ebeb-153c-469c-9854-e7ceb7a7e7c3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Report UI Overview</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4e9f39cc-2d99-4afb-8bed-fda6f600d494</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Exam UI Overview</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>26eaf546-e844-4315-8d0a-0083c3cb61a1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Introduction UI Overview</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
